---
title: Onboarding Guide — Citizens & Contributors
version: 1.0
---

# Onboarding Guide
1. Claim your DID at `id.the.network` (placeholder).  
2. Read and sign the Charter.  
3. Obtain Builder/Deployer credential (VC).  
4. Join Assembly votes; run nodes; contribute code/docs.  
5. Track PoC and Treasury via metrics dashboards.
