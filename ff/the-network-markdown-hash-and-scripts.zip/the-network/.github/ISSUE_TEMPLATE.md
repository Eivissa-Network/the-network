## Type
- [ ] Bug
- [ ] Doc enhancement
- [ ] Proposal
- [ ] Governance

## Description
Describe the issue/proposal.

## Acceptance
- [ ] Linked docs
- [ ] Clear outcome
- [ ] Owner
