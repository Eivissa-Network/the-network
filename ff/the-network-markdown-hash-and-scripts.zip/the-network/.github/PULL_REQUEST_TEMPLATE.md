## Summary
- What does this change?

## Scope
- [ ] Constitutional text
- [ ] Economic model
- [ ] Governance spec
- [ ] Docs

## Integrity checklist
- [ ] Updated hashes (if changing ratified files)
- [ ] Added/updated cross-links
- [ ] Included references to source PDFs where applicable
