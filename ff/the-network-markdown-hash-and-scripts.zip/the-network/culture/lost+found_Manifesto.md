---
title: lost+found — The Manifesto
version: 1.0
source_pdf: lost+found — The Manifesto.pdf
license: CC BY 4.0
---

# lost+found — The Manifesto
The place where wandering citizens find consensus.

I. We Begin Lost.  
II. We Remember the Network.  
III. We Claim Our Right to Be Found.  
IV. We Anchor Trust in Integrity.  
V. We Forge Consensus.  
VI. We Are The Found.

**The Declaration**  
“We, the Found, acknowledge that The Network exists where code and conscience align.” — Ratified at LOST, Ibiza, under the Charter.
